//
//  TabType.swift
//  CustomTabBarNavigation
//
//  Created by Constantin Senila on 28.02.2024.
//

import Foundation

enum TabType {
    case mainTab
    case editTab
}
